NexStock Phase 3 developer handoff - 17 November 2026
Read SUMMARY.md and the PDF, then the single cumulative PHASE3-BUGS.md.
Bug screenshot links are portable within this archive. Requirement dispositions include partial, blocked and skipped checks.
This curated bundle excludes environment files, authentication storage, JWTs, passwords, recovery state and minted API keys.
Raw Playwright runs stay in the QA repository archive; they are not included wholesale.
